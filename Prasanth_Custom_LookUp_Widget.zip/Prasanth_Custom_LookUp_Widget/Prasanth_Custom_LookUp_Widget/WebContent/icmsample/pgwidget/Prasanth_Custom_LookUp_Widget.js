define([
    "dojo/_base/declare",
    "icm/base/BasePageWidget",
    "icm/base/_BaseWidget",
    "dojo/text!./templates/Prasanth_Custom_LookUp_Widget.html",
    "ecm/model/Request",
    "dijit/Dialog",
    "dijit/form/TextBox",
    "dijit/form/Button",
    "dojo/dom-construct"
], function(
    declare,
    BasePageWidget,
    _BaseWidget,
    template,
    Request,
    Dialog,
    TextBox,
    Button,
    domConstruct
) {
    return declare(
        "icmsample.pgwidget.Prasanth_Custom_LookUp_Widget",
        [_BaseWidget, BasePageWidget],
        {
            templateString: template,

            // =================================
            // POST CREATE
            postCreate: function() {
                this.inherited(arguments);
                console.log("=================================");
                console.log("Widget Loaded...");
                console.log("=================================");
            },

            // =================================
            // FORMAT DATE FOR DB (yyyy-mm-dd hh:mm:ss)
            formatDateForDB: function(value) {

                if (!value) {
                    return "";
                }

                var d = (value instanceof Date) ? value : new Date(value);

                if (isNaN(d.getTime())) {
                    return "";
                }

                function pad(n) {
                    return n < 10 ? "0" + n : "" + n;
                }

                return d.getFullYear() + "-" +
                    pad(d.getMonth() + 1) + "-" +
                    pad(d.getDate()) + " " +
                    pad(d.getHours()) + ":" +
                    pad(d.getMinutes()) + ":" +
                    pad(d.getSeconds());
            },

            // =================================
            // ADD LOOKUP ICON
            addLookupIcon: function() {

                try {

                    var mapping = this.getPropertyMapping(this.solutionId);

                    if (!mapping) {
                        console.log("No Property Mapping Found");
                        return;
                    }

                    var oldWrapper = document.getElementById("policyLookupWrapper");

                    if (oldWrapper) {
                        oldWrapper.remove();
                    }

                    var textBox = null;

                    var editors = document.querySelectorAll("[aria-labelledby]");

                    for (var i = 0; i < editors.length; i++) {

                        var labelId = editors[i].getAttribute("aria-labelledby");

                        if (!labelId) {
                            continue;
                        }

                        var label = document.getElementById(labelId);

                        if (label && label.innerText === mapping.lookupLabel) {

                            textBox = editors[i];

                            console.log("Policy Number TextBox Found", textBox.id);

                            break;
                        }
                    }

                    if (!textBox) {
                        console.log("Policy Number TextBox Not Found");
                        return;
                    }

                    var textBoxContainer = textBox.closest(".pvrPropertyEditor");

                    if (!textBoxContainer) {
                        console.log("Property Editor Container Not Found");
                        return;
                    }

                    var wrapper = document.createElement("div");

                    wrapper.id = "policyLookupWrapper";
                    wrapper.style.display = "flex";
                    wrapper.style.alignItems = "center";
                    wrapper.style.gap = "8px";

                    textBoxContainer.parentNode.insertBefore(
                        wrapper,
                        textBoxContainer
                    );

                    wrapper.appendChild(textBoxContainer);

                    var icon = document.createElement("span");

                    icon.id = "policyLookupIcon";
                    icon.innerHTML = "🔍";
                    icon.style.cursor = "pointer";
                    icon.style.fontSize = "18px";
                    icon.style.color = "#0f62fe";
                    icon.title = "Policy Lookup";

                    var self = this;

                    icon.onclick = function() {
                        self.openLookupDialog();
                    };

                    wrapper.appendChild(icon);

                    console.log("Lookup Icon Added Successfully");

                } catch (e) {

                    console.error("Policy Lookup Icon Error", e);
                }
            },

            // =================================
            // OPEN LOOKUP DIALOG
            openLookupDialog: function() {

                var self = this;

                var mapping = this.getPropertyMapping(this.solutionId);

                var dialog = new Dialog({
                    title: mapping.dialogTitle
                });

                var container = domConstruct.create("div", {
                    style: "padding:15px;width:600px;"
                });

                domConstruct.create("label", {
                    innerHTML: mapping.searchLabel
                }, container);

                var policyTextBox = new TextBox({
                    style: "width:250px;margin-top:5px;"
                });

                policyTextBox.placeAt(container);

                domConstruct.create("br", {}, container);
                domConstruct.create("br", {}, container);

                var searchButton = new Button({
                    label: "Search"
                });

                searchButton.placeAt(container);

                var resultDiv = domConstruct.create("div", {
                    style: "margin-top:15px;"
                }, container);

                searchButton.on("click", function() {

                    var lookupValue = policyTextBox.get("value");

                    Request.invokePluginService(
                        "Prasanth_Custom_LookUp_Plugin",
                        "ClaimDataLookUpSearchService",
                        {
                            requestParams: {
                                LookupValue: lookupValue,
                                SolutionId: self.solutionId
                            },

                            requestCompleteCallback: function(response) {

                                if (response && response.status === "success") {

                                    var tableHtml =
                                        "<table style='width:100%;border-collapse:collapse'>" +
                                        "<tr style='background:#d9e8fb'>";

                                    for (var key in response) {

                                        if (key === "status") {
                                            continue;
                                        }

                                        tableHtml +=
                                            "<th style='border:1px solid black;padding:5px'>" +
                                            key +
                                            "</th>";
                                    }

                                    tableHtml += "</tr>";

                                    tableHtml += "<tr id='lookupRow' style='cursor:pointer'>";

                                    for (var key2 in response) {

                                        if (key2 === "status") {
                                            continue;
                                        }

                                        tableHtml +=
                                            "<td style='border:1px solid black;padding:5px'>" +
                                            response[key2] +
                                            "</td>";
                                    }

                                    tableHtml += "</tr></table>";

                                    resultDiv.innerHTML = tableHtml;

                                    setTimeout(function() {

                                        var row = document.getElementById("lookupRow");

                                        if (row) {

                                            row.onmouseover = function() {
                                                this.style.backgroundColor = "#e8f4ff";
                                            };

                                            row.onmouseout = function() {
                                                this.style.backgroundColor = "#ffffff";
                                            };

                                            row.onclick = function() {

                                                console.log("Selected Record : ", response);

                                                self.populateCaseProperties(
                                                    response,
                                                    dialog
                                                );
                                            };
                                        }
                                    }, 100);

                                } else {

                                    resultDiv.innerHTML =
                                        "<span style='color:red'>" +
                                        "No Record Found" +
                                        "</span>";
                                }
                            },

                            requestFailedCallback: function(error) {

                                console.error(error);

                                resultDiv.innerHTML =
                                    "<span style='color:red'>" +
                                    "Search Failed" +
                                    "</span>";
                            }
                        }
                    );
                });

                dialog.set("content", container);
                dialog.show();
            },

            // =================================
            // POPULATE CASE PROPERTIES
            populateCaseProperties: function(response, dialog) {

                if (!this.caseCollection) {
                    console.error("Case Collection Not Available");
                    return;
                }

                var mapping = this.getPropertyMapping(this.solutionId);

                if (!mapping) {
                    console.error(
                        "No Property Mapping Found For Solution : " + this.solutionId
                    );
                    return;
                }

                var props = this.caseCollection;

                function setProp(propertyName, value) {

                    if (!props[propertyName]) {
                        console.log(propertyName + " Not Found");
                        return;
                    }

                    try {

                        if (props[propertyName].setValue) {

                            // Clear existing value first
                            props[propertyName].setValue("");

                            // Set new value
                            props[propertyName].setValue(value);

                        } else {

                            props[propertyName].value = "";
                            props[propertyName].value = value;
                        }

                        props[propertyName].dirty = true;

                        if (props[propertyName].onValueChanged) {
                            props[propertyName].onValueChanged(value);
                        }

                        console.log(propertyName + " Updated To : ", value);

                        console.log(
                            "Current Property Value : ",
                            props[propertyName].value
                        );

                    } catch (e) {

                        console.error(
                            "Error Updating Property : " + propertyName,
                            e
                        );
                    }
                }

                console.log("Populating Data...");
                console.log(response);

                for (var key in mapping.responseMappings) {

                    if (response[key] !== undefined && response[key] !== null) {

                        var value = response[key];

                        if (key === "IncidentDate") {

                            // DB format "yyyy-mm-dd hh:mm:ss.f" -> ISO-like for reliable parsing
                            if (typeof value === "string") {
                                value = value.replace(" ", "T");
                            }

                            value = new Date(value);
                        }

                        setProp(mapping.responseMappings[key], value);
                    }
                }

                console.log("Fields Auto Populated Successfully");

                if (this.caseEditable && this.caseEditable.onChange) {
                    this.caseEditable.onChange();
                }

                dialog.hide();
            },

            // =================================
            // GET SOLUTION INFO
            getSolutionInfo: function() {

                var info = {
                    solutionId: "",
                    solutionName: "",
                    caseTypeId: "",
                    caseTypeName: ""
                };

                try {

                    if (this.caseEditable && this.caseEditable.caseType) {

                        info.caseTypeId = this.caseEditable.caseType.id || "";
                        info.caseTypeName = this.caseEditable.caseType.name || "";

                        if (this.caseEditable.caseType.solution) {

                            info.solutionId =
                                this.caseEditable.caseType.solution.id || "";

                            info.solutionName =
                                this.caseEditable.caseType.solution.name || "";
                        }
                    }

                } catch (e) {

                    console.error("Error getting solution information", e);
                }

                return info;
            },

            // =================================
            // PROPERTY MAPPING
            getPropertyMapping: function(solutionId) {

                var mappings = {

                    "PK_Insurance Claims Management": {

                        lookupProperty: "PKICM_PolicyNumber",
                        lookupLabel: "PolicyNumber",
                        dialogTitle: "InsurancePolicy Lookup",
                        searchLabel: "Policy Number",
                        searchColumn: "POLICY_NUMBER",

                        responseMappings: {
                            PolicyNumber: "PKICM_PolicyNumber",
                            ClaimantName: "PKICM_ClaimantName",
                            ClaimType: "PKICM_ClaimType",
                            IncidentDate: "PKICM_IncidentDate"
                        }
                    },

                    "PK_CreditCard Application": {

                        lookupProperty: "PKCA_Card_Number",
                        lookupLabel: "Card_Number",
                        dialogTitle: "CreditCard Lookup",
                        searchLabel: "Card Number",
                        searchColumn: "CARD_NUMBER",

                        responseMappings: {
                            CardNumber: "PKCA_Card_Number",
                            CustomerName: "PKCA_customerName",
                            CustomerAge: "PKCA_customerAge",
                            CustomerGender: "PKCA_customerGender"
                        }
                    }
                };

                return mappings[solutionId];
            },

            // =================================
            // CASE CREATED
            CaseCreated: function(payload) {

                console.log("=================================");
                console.log("PAYLOAD RECEIVED");
                console.log("=================================");

                console.log("FULL PAYLOAD");
                console.log(payload);

                if (!payload || !payload.caseEditable) {
                    console.error("Case Editable not available");
                    return;
                }

                // =================================
                // STORE REFERENCES
                this.caseEditable = payload.caseEditable;
                this.caseCollection = payload.caseEditable.propertiesCollection;

                var solutionInfo = this.getSolutionInfo();

                this.solutionId = solutionInfo.solutionId;
                this.solutionName = solutionInfo.solutionName;
                this.caseTypeId = solutionInfo.caseTypeId;
                this.caseTypeName = solutionInfo.caseTypeName;

                for (var prop in this.caseCollection) {
                    console.log("Property = ", prop);
                }

                console.log("Solution ID : ", this.solutionId);
                console.log("Solution Name : ", this.solutionName);
                console.log("Case Type ID : ", this.caseTypeId);
                console.log("Case Type Name : ", this.caseTypeName);

                console.log("=================================");
                console.log("CURRENT CONFIGURATION");
                console.log("=================================");
                console.log("Case Type ID : ", this.caseTypeId);
                console.log("Case Type Name : ", this.caseTypeName);
                console.log("Solution ID : ", this.solutionId);
                console.log("Solution Name : ", this.solutionName);

                var collection = payload.caseEditable.propertiesCollection;

                var self = this;

                if (payload.coordination) {

                    // =================================
                    // AFTER LOAD WIDGET
                    payload.coordination.participate(
                        "AFTERLOADWIDGET",
                        function(context, complete, abort) {

                            console.log("AFTERLOADWIDGET Triggered");

                            self.addLookupIcon();

                            complete();
                        }
                    );

                    // =================================
                    // AFTER SAVE
                    payload.coordination.participate(
                        "AFTERSAVE",
                        function(context, complete, abort) {

                            console.log("===== CLAIM DATA AFTER SAVE =====");

                            var mapping = self.getPropertyMapping(self.solutionId);

                            if (!mapping) {

                                console.error(
                                    "No Property Mapping Found For Solution : " +
                                    self.solutionId
                                );

                                complete();
                                return;
                            }

                            self.lookupProperty = mapping.lookupProperty;

                            console.log("Lookup Property = ", self.lookupProperty);

                            var saveData = {};

                            for (var key in mapping.responseMappings) {

                                var propertyName = mapping.responseMappings[key];

                                if (collection[propertyName]) {

                                    var val = collection[propertyName].value;

                                    // Convert date to yyyy-mm-dd hh:mm:ss for the DB service
                                    if (key === "IncidentDate") {
                                        val = self.formatDateForDB(val);
                                    }

                                    saveData[key] = val;
                                }
                            }

                            saveData.CaseType = self.caseTypeId;
                            saveData.SolutionName = self.solutionName;

                            console.log("Save Data : ", saveData);

                            Request.invokePluginService(
                                "Prasanth_Custom_LookUp_Plugin",
                                "ClaimDataInsertToDBService",
                                {
                                    requestParams: saveData,

                                    requestCompleteCallback: function(response) {

                                        console.log("===== DB INSERT RESPONSE =====");
                                        console.log(response);

                                        complete();
                                    },

                                    requestFailedCallback: function(error) {

                                        console.error("===== DB INSERT FAILED =====");
                                        console.error(error);

                                        complete();
                                    }
                                }
                            );
                        }
                    );
                }
            }
        }
    );
});