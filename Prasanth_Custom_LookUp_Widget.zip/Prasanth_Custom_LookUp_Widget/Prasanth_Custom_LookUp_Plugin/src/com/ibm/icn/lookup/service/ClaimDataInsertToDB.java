package com.ibm.icn.lookup.service;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;

public class ClaimDataInsertToDB extends PluginService {

    @Override
    public String getId() {
        return "ClaimDataInsertToDBService";
    }

    @Override
    public void execute(
            PluginServiceCallbacks callbacks,
            HttpServletRequest request,
            HttpServletResponse response)
            throws Exception {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        Connection conn = null;
        PreparedStatement ps = null;
        PrintWriter out = response.getWriter();

        try {

            System.out.println(
                    "===== INSERT SERVICE STARTED =====");

            String solutionName =
                    request.getParameter(
                            "SolutionName");

            System.out.println(
                    "Solution Name : "
                            + solutionName);

            Class.forName(
                    "com.ibm.db2.jcc.DB2Driver");

            conn = DriverManager.getConnection(
                    "jdbc:db2://localhost:50000/CMTGDB",
                    "fnadmin",
                    "Admin@123");

            System.out.println(
                    "DB Connected Successfully");

            // =====================================
            // INSURANCE
            // =====================================

            if ("PK_Insurance Claims Management"
                    .equals(solutionName)) {

                String policyNumber =
                        request.getParameter(
                                "PolicyNumber");

                String claimantName =
                        request.getParameter(
                                "ClaimantName");

                String claimType =
                        request.getParameter(
                                "ClaimType");

                String incidentDate =
                        request.getParameter(
                                "IncidentDate");

                System.out.println(
                        "Policy Number : "
                                + policyNumber);

                System.out.println(
                        "Claimant Name : "
                                + claimantName);

                System.out.println(
                        "Claim Type : "
                                + claimType);

                System.out.println(
                        "Incident Date : "
                                + incidentDate);

                String sql =
                        "INSERT INTO FNADMIN.PK_CLAIM_DATA "
                        + "(POLICY_NUMBER, CLAIMANT_NAME, CLAIM_TYPE, INCIDENT_DATE) "
                        + "VALUES (?, ?, ?, ?)";

                ps = conn.prepareStatement(sql);

                ps.setString(
                        1,
                        policyNumber);

                ps.setString(
                        2,
                        claimantName);

                ps.setString(
                        3,
                        claimType);

                ps.setTimestamp(
                        4,
                        java.sql.Timestamp.valueOf(
                                incidentDate));
            }

            // =====================================
            // CREDIT CARD
            // =====================================

            else if ("PK_CreditCard Application"
                    .equals(solutionName)) {

                String cardNumber =
                        request.getParameter(
                                "CardNumber");

                String customerName =
                        request.getParameter(
                                "CustomerName");

                String customerAge =
                        request.getParameter(
                                "CustomerAge");

                String customerGender =
                        request.getParameter(
                                "CustomerGender");

                System.out.println(
                        "Card Number : "
                                + cardNumber);

                System.out.println(
                        "Customer Name : "
                                + customerName);

                System.out.println(
                        "Customer Age : "
                                + customerAge);

                System.out.println(
                        "Customer Gender : "
                                + customerGender);

                String sql =
                        "INSERT INTO FNADMIN.PK_CREDITCARD_DATA "
                        + "(CARD_NUMBER, CUSTOMER_NAME, CUSTOMER_AGE, CUSTOMER_GENDER) "
                        + "VALUES (?, ?, ?, ?)";

                ps = conn.prepareStatement(sql);

                ps.setString(
                        1,
                        cardNumber);

                ps.setString(
                        2,
                        customerName);

                if (customerAge != null
                        && !customerAge.isEmpty()) {

                    ps.setInt(
                            3,
                            Integer.parseInt(
                                    customerAge));
                } else {

                    ps.setNull(
                            3,
                            java.sql.Types.INTEGER);
                }

                ps.setString(
                        4,
                        customerGender);
            }

            // =====================================
            // NO SOLUTION FOUND
            // =====================================

            else {

                out.print(
                        "{"
                        + "\"status\":\"error\","
                        + "\"message\":\"Unsupported Solution\""
                        + "}");

                out.flush();
                return;
            }

            int rows =
                    ps.executeUpdate();

            System.out.println(
                    "Rows Inserted : "
                            + rows);

            out.print(
                    "{"
                    + "\"status\":\"success\","
                    + "\"rowsInserted\":\""
                    + rows
                    + "\""
                    + "}");

            out.flush();

        } catch (Exception e) {

            e.printStackTrace();

            out.print(
                    "{"
                    + "\"status\":\"error\","
                    + "\"message\":\""
                    + e.getMessage()
                    + "\""
                    + "}");

            out.flush();

        } finally {

            try {

                if (ps != null) {
                    ps.close();
                }

                if (conn != null) {
                    conn.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        System.out.println(
                "===== INSERT SERVICE END =====");
    }
}