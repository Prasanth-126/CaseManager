package com.ibm.icn.lookup.service;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;

public class ClaimDataLookUpSearch extends PluginService {

    @Override
    public String getId() {
        return "ClaimDataLookUpSearchService";
    }

    @Override
    public void execute(
            PluginServiceCallbacks callbacks,
            HttpServletRequest request,
            HttpServletResponse response)
            throws Exception {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        PrintWriter out = response.getWriter();

        try {

            System.out.println("===== LOOKUP SEARCH STARTED =====");

            String lookupValue  =request.getParameter("LookupValue");

            String solutionId =request.getParameter("SolutionId");

            System.out.println("Policy Number : " + lookupValue );

            System.out.println("Solution Id : " + solutionId);

            if (lookupValue  == null|| lookupValue .trim().isEmpty()) {

                out.print(
                        "{"
                        + "\"status\":\"error\","
                        + "\"message\":\"Policy Number Is Required\""
                        + "}");

                out.flush();
                return;
            }

            String tableName =getTableName(solutionId);

            System.out.println("Resolved Table Name : "+ tableName);

            if (tableName == null || tableName.isEmpty()) {

                out.print(
                        "{"
                        + "\"status\":\"error\","
                        + "\"message\":\"No Table Mapping Found For Solution\""
                        + "}");

                out.flush();
                return;
            }

            Class.forName(
                    "com.ibm.db2.jcc.DB2Driver");

            conn = DriverManager.getConnection(
                    "jdbc:db2://localhost:50000/CMTGDB",
                    "fnadmin",
                    "Admin@123");

            System.out.println("DB Connected Successfully");

            String sql =getLookupQuery(solutionId);
            System.out.println("SQL : " + sql);

            ps = conn.prepareStatement(sql);

            ps.setString(1, lookupValue);

            rs = ps.executeQuery();

            if (rs.next()) {

                String json = "";

                if ("PK_Insurance Claims Management"
                        .equals(solutionId)) {

                    json =
                            "{"
                            + "\"status\":\"success\","
                            + "\"PolicyNumber\":\""
                            + rs.getString("POLICY_NUMBER")
                            + "\","
                            + "\"ClaimantName\":\""
                            + rs.getString("CLAIMANT_NAME")
                            + "\","
                            + "\"ClaimType\":\""
                            + rs.getString("CLAIM_TYPE")
                            + "\","
                            + "\"IncidentDate\":\""
                            + rs.getTimestamp("INCIDENT_DATE")
                            + "\""
                            + "}";
                }

                else if ("PK_CreditCard Application"
                        .equals(solutionId)) {

                    json =
                            "{"
                            + "\"status\":\"success\","
                            + "\"CardNumber\":\""
                            + rs.getString("CARD_NUMBER")
                            + "\","
                            + "\"CustomerName\":\""
                            + rs.getString("CUSTOMER_NAME")
                            + "\","
                            + "\"CustomerAge\":\""
                            + rs.getString("CUSTOMER_AGE")
                            + "\","
                            + "\"CustomerGender\":\""
                            + rs.getString("CUSTOMER_GENDER")
                            + "\""
                            + "}";
                }

                out.print(json);
            
            } else {

                out.print(
                        "{"
                        + "\"status\":\"notfound\","
                        + "\"message\":\"No Record Found\""
                        + "}");
            }

            out.flush();

        } catch (Exception e) {

            e.printStackTrace();

            out.print(
                    "{"
                    + "\"status\":\"error\","
                    + "\"message\":\""
                    + e.getMessage()
                    + "\""
                    + "}");

            out.flush();

        } finally {

            try {

                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }

                if (conn != null) {
                    conn.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        System.out.println("===== LOOKUP SEARCH END =====");
    }
    
    private String getLookupQuery(String solutionId) {

        if ("PK_Insurance Claims Management".equals(solutionId)) {

            return "SELECT POLICY_NUMBER, " +
                   "CLAIMANT_NAME, " +
                   "CLAIM_TYPE, " +
                   "INCIDENT_DATE " +
                   "FROM FNADMIN.PK_CLAIM_DATA " +
                   "WHERE POLICY_NUMBER = ?";
        }

        if ("PK_CreditCard Application"
                .equals(solutionId)) {

            return "SELECT CARD_NUMBER, " +
                   "CUSTOMER_NAME, " +
                   "CUSTOMER_AGE, " +
                   "CUSTOMER_GENDER " +
                   "FROM FNADMIN.PK_CREDITCARD_DATA " +
                   "WHERE CARD_NUMBER = ?";
        }

        return null;
    }

    private String getTableName(
            String solutionId) {

        if (solutionId == null) {
            return null;
        }

        if ("PK_Insurance Claims Management"
                .equals(solutionId)) {

            return "FNADMIN.PK_CLAIM_DATA";
        }
        
        if ("PK_CreditCard Application"
                .equals(solutionId)) {

            return "FNADMIN.PK_CREDITCARD_DATA";
        }

        /*
        Future Solutions

        if ("Customer Management"
                .equals(solutionId)) {

            return "FNADMIN.CUSTOMER_DATA";
        }

        if ("Employee Management"
                .equals(solutionId)) {

            return "FNADMIN.EMPLOYEE_DATA";
        }
        */

        return null;
    }
}