package com.ibm.icn.lookup.service;

import java.io.PrintWriter;
import java.util.Iterator;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.IndependentObject;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.Properties;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.UserContext;

import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.json.java.JSONObject;

public class LookupService extends PluginService {

    @Override
    public String getId() {
        return "LookupService";
    }

    @Override
    public void execute(
            PluginServiceCallbacks callbacks,
            HttpServletRequest request,
            HttpServletResponse response)
            throws Exception {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        JSONObject json = new JSONObject();

        try {

            String searchType =
                    request.getParameter("searchType");

            String searchValue =
                    request.getParameter("searchValue");

            System.out.println(
                    "=================================");

            System.out.println(
                    "Lookup Service Started");

            System.out.println(
                    "Search Type : " +
                    searchType);

            System.out.println(
                    "Search Value : " +
                    searchValue);

            System.out.println(
                    "=================================");

            Connection connection =
                    Factory.Connection.getConnection(
                    "http://172.16.10.83:9080/wsi/FNCEWS40MTOM/");

            Subject subject =
                    UserContext.createSubject(
                    connection,
                    "fnadmin",
                    "Admin@123",
                    null);

            UserContext.get().pushSubject(subject);

            Domain domain =
                    Factory.Domain.fetchInstance(
                    connection,
                    null,
                    null);

            ObjectStore objectStore =
                    Factory.ObjectStore.fetchInstance(
                    domain,
                    "CMTOS",
                    null);

            String sql =
                    "SELECT * FROM PK_InsuranceClaim";

            System.out.println(
                    "SQL = " + sql);

            SearchSQL searchSQL =
                    new SearchSQL(sql);

            SearchScope searchScope =
                    new SearchScope(objectStore);

            IndependentObjectSet results =
                    searchScope.fetchObjects(
                    searchSQL,
                    null,
                    null,
                    Boolean.TRUE);

            Iterator<?> iterator =
                    results.iterator();

            boolean found = false;

            while (iterator.hasNext()) {

                found = true;

                IndependentObject object =
                        (IndependentObject)
                        iterator.next();

                Properties props =
                        object.getProperties();

                System.out.println(
                        "==================================");
                System.out.println(
                        "RECORD FOUND");
                System.out.println(
                        "==================================");

                try {

                    String policyNumber =
                            props.getStringValue(
                            "PKICM_PolicyNumber");

                    System.out.println(
                            "PolicyNumber = "
                            + policyNumber);

                } catch (Exception e) {

                    System.out.println(
                            "PKICM_PolicyNumber NOT FOUND");
                }

                try {

                    String claimantName =
                            props.getStringValue(
                            "PKICM_ClaimantName");

                    System.out.println(
                            "ClaimantName = "
                            + claimantName);

                } catch (Exception e) {

                    System.out.println(
                            "PKICM_ClaimantName NOT FOUND");
                }

                try {

                    String claimType =
                            props.getStringValue(
                            "PKICM_ClaimType");

                    System.out.println(
                            "ClaimType = "
                            + claimType);

                } catch (Exception e) {

                    System.out.println(
                            "PKICM_ClaimType NOT FOUND");
                }

                try {

                    String claimStatus =
                            props.getStringValue(
                            "PKICM_ClaimStatus");

                    System.out.println(
                            "ClaimStatus = "
                            + claimStatus);

                } catch (Exception e) {

                    System.out.println(
                            "PKICM_ClaimStatus NOT FOUND");
                }

                System.out.println(
                        "==================================");
            }

            if (found) {

                json.put(
                        "status",
                        "success");

                json.put(
                        "message",
                        "Records Found. Check Logs.");
            }
            else {

                System.out.println(
                        "NO RECORDS FOUND");

                json.put(
                        "status",
                        "notfound");

                json.put(
                        "message",
                        "No Records Found In Class");
            }

            UserContext.get().popSubject();
        }
        catch (Exception e) {

            e.printStackTrace();

            System.out.println(
                    "ERROR OCCURRED : "
                    + e.getMessage());

            json.put(
                    "status",
                    "error");

            json.put(
                    "message",
                    e.getMessage());
        }

        System.out.println(
                "JSON RESPONSE = "
                + json.toString());

        PrintWriter out =
                response.getWriter();

        out.print(
                json.toString());

        out.flush();
    }
}