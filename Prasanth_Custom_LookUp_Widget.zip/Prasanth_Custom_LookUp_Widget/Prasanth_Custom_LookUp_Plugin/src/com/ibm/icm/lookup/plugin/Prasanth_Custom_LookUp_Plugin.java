package com.ibm.icm.lookup.plugin;

import java.util.Locale;
import com.ibm.ecm.extension.Plugin;
import com.ibm.ecm.extension.PluginAction;
import com.ibm.ecm.extension.PluginService;
import com.ibm.icn.lookup.service.ClaimDataInsertToDB;
import com.ibm.icn.lookup.service.ClaimDataLookUpSearch;
import com.ibm.icn.lookup.service.EmailNotificationService;
import com.ibm.icn.lookup.service.LookupService;

public class Prasanth_Custom_LookUp_Plugin extends Plugin {

	@Override
	public String getId() {
		return "Prasanth_Custom_LookUp_Plugin";
	}

	@Override
	public String getName(Locale arg0) {
		return "Prasanth_Custom_LookUp_Plugin";
	}

	@Override
	public String getVersion() {
		return "1.0.0";
	}

	@Override
	public PluginAction[] getActions() {
		return new PluginAction[] {};
	}

	@Override
	public String getScript() {
		return "Prasanth_Custom_LookUp_Plugin.js";
	}

	@Override
	public String getDojoModule() {
		return "icmsample";
	}

	@Override
	public String getCSSFileName() {
		return "Prasanth_Custom_LookUp_Plugin.css";
	}

	@Override
	public PluginService[] getServices() {

		return new PluginService[] { new LookupService(), new ClaimDataInsertToDB(), new ClaimDataLookUpSearch(), new EmailNotificationService() };
	}

}
